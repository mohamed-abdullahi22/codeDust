//question 1
// try ch the  number on the "createcanva"and "background"
function setup() {
  createCanvas(550, 400);
  
}

function draw() {
  background(500,100,  700,300);
  triangle(30,30,276,200,26,200);
  fill(78,66,22)
  ellipseMode(CENTER);
  
}