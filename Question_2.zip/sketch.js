function setup() {
  createCanvas(400, 400); 
}
function draw() {
  background(50,300,200); 
  rect(100,300,130,44)
  fill(300);
  ellipse(120,94,100,60);
  fill(100);
}