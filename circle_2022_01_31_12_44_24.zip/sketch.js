function setup() {
  createCanvas(600, 600);
  
}
  
  
  function draw(){
  background(0);
    
  stroke(255);
  strokeWeight(4)
  noFill();
    
  if(mouseX > 300){
    fill(00,200,50);
}
ellipse(300,300,100, 20);

}