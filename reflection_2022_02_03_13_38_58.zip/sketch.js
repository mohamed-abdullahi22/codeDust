var on = false;

function setup() {
  createCanvas(600, 400);
}

function draw() {
  if (on) {
    background(0,255,200);
  }
  else{
    background(100);
  }
  stroke(255);
  strokeWeight(4);
  noFill();
  if (mouseX > 250 && mouseX < 350 && mouseY >150 && mouseY < 250);{
    fill(300);
  }
  if (mouseX > 150 && mouseX < 250 && mouseY >100 && mouseY < 200);{
    fill(300,0,200,300);
  }
  rectMode(CENTER);
  rect (300,200,100,100);
  fill(0,255,200);
  rect(100,40,130,60);
  
}
function mousePressed(){
  if (mouseX > 250 && mouseX < 350 && mouseY >150 && mouseY < 250);{
    on = !on;
  
}
  
    
  
}
  function mousePressed(){
  if (mouseX > 150 && mouseX < 250 && mouseY >100 && mouseY < 200);{
     on = !on;
  }
   
  
  
}